cp -r plugin.video.easynews/ ~/Library/Application\ Support/Kodi/addons
